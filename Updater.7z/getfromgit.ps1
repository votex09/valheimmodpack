Clear-Host
Write-Host "Downloading mod package from git..."
#Invoke-WebRequest https://github.com/votex09/valheimdirtbagmodpack/archive/main.zip -O $PSScriptRoot\PackBin\pack.zip
& "$PSScriptRoot\PackBin\7z\7za.exe" x "$PSScriptRoot\PackBin\pack.zip" "-o$PSScriptRoot\PackBin\unpack\"
Remove-Item -Path "$PSScriptRoot\BepInEx\Plugins\*"
Robocopy ("$PSScriptRoot\PackBin\unpack\valheimdirtbagmodpack-main\ ") ("$PSScriptRoot ") /E
#Clear-Host
Write-Host "Cleaning up..."
Remove-Item "$PSscriptRoot\PackBin\Unpack\*" -Recurse
#Clear-Host
Write-Host "Complete." -ForegroundColor Green
Pause